
export type Player = 'X' | 'O' | null;

export type GameMode = 'friends' | 'computer';

export interface GameState {
  board: Player[];
  xIsNext: boolean;
  winner: Player;
  isDraw: boolean;
  winningLine: number[] | null;
}

export interface Score {
  X: number;
  O: number;
  draws: number;
}

export enum Theme {
  LIGHT = 'light',
  DARK = 'dark'
}

export interface GameHistoryItem {
  id: string;
  winner: Player | 'Draw';
  timestamp: number;
  score: Score;
  mode: GameMode;
}
