
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Player, GameMode, Score, Theme, GameHistoryItem } from './types';
import { WINNING_LINES, INITIAL_BOARD } from './constants';
import ScoreBoard from './components/ScoreBoard';
import StatusIndicator from './components/StatusIndicator';
import Board from './components/Board';
import Controls from './components/Controls';
import Header from './components/Header';
import WinPopup from './components/WinPopup';
import StartScreen from './components/StartScreen';
import HelpModal from './components/HelpModal';
import HistoryModal from './components/HistoryModal';

const App: React.FC = () => {
  const [isStarted, setIsStarted] = useState<boolean>(false);
  const [gameMode, setGameMode] = useState<GameMode>('friends');
  const [isHelpOpen, setIsHelpOpen] = useState<boolean>(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);
  const [board, setBoard] = useState<Player[]>(INITIAL_BOARD);
  const [xIsNext, setXIsNext] = useState<boolean>(true);
  const [scores, setScores] = useState<Score>({ X: 0, O: 0, draws: 0 });
  const [history, setHistory] = useState<GameHistoryItem[]>([]);
  const [theme, setTheme] = useState<Theme>(Theme.LIGHT);
  const [isGameActive, setIsGameActive] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isAiThinking, setIsAiThinking] = useState<boolean>(false);
  
  const audioContextRef = useRef<AudioContext | null>(null);

  // Load persistence data
  useEffect(() => {
    const savedHistory = localStorage.getItem('zen_ttt_history');
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory));
      } catch (e) {
        console.error("Failed to parse history", e);
      }
    }
    
    const savedScores = localStorage.getItem('zen_ttt_scores');
    if (savedScores) {
      try {
        setScores(JSON.parse(savedScores));
      } catch (e) {
        console.error("Failed to parse scores", e);
      }
    }
  }, []);

  const initAudio = () => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  };

  const playSound = (type: 'move' | 'win' | 'draw') => {
    if (isMuted) return;
    initAudio();
    const ctx = audioContextRef.current!;
    if (ctx.state === 'suspended') ctx.resume();

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.connect(gain);
    gain.connect(ctx.destination);

    const now = ctx.currentTime;

    if (type === 'move') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, now);
      osc.frequency.exponentialRampToValueAtTime(440, now + 0.1);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
      osc.start(now);
      osc.stop(now + 0.1);
    } else if (type === 'win') {
      osc.type = 'sine';
      [523.25, 659.25, 783.99].forEach((freq, i) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = 'sine';
        o.frequency.setValueAtTime(freq, now + i * 0.1);
        g.connect(ctx.destination);
        o.connect(g);
        g.gain.setValueAtTime(0, now + i * 0.1);
        g.gain.linearRampToValueAtTime(0.1, now + i * 0.1 + 0.05);
        g.gain.exponentialRampToValueAtTime(0.01, now + i * 0.1 + 0.4);
        o.start(now + i * 0.1);
        o.stop(now + i * 0.1 + 0.4);
      });
    } else if (type === 'draw') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(330, now);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
      osc.start(now);
      osc.stop(now + 0.3);
    }
  };

  const calculateResult = (squares: Player[]) => {
    for (let i = 0; i < WINNING_LINES.length; i++) {
      const [a, b, c] = WINNING_LINES[i];
      if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
        return { winner: squares[a], line: WINNING_LINES[i] };
      }
    }
    const isDraw = squares.every((square) => square !== null);
    return { winner: null, line: null, isDraw };
  };

  const findBestMove = (squares: Player[]): number => {
    const available = squares.map((v, i) => v === null ? i : null).filter(v => v !== null) as number[];
    
    // 1. Try to win
    for (const move of available) {
      const copy = [...squares];
      copy[move] = 'O';
      if (calculateResult(copy).winner === 'O') return move;
    }
    
    // 2. Block player
    for (const move of available) {
      const copy = [...squares];
      copy[move] = 'X';
      if (calculateResult(copy).winner === 'X') return move;
    }
    
    // 3. Take center
    if (squares[4] === null) return 4;
    
    // 4. Random
    return available[Math.floor(Math.random() * available.length)];
  };

  const { winner, line: winningLine, isDraw } = calculateResult(board);

  const addHistoryEntry = useCallback((result: Player | 'Draw', currentScores: Score) => {
    const newEntry: GameHistoryItem = {
      id: Date.now().toString(),
      winner: result,
      timestamp: Date.now(),
      score: { ...currentScores },
      mode: gameMode
    };
    const updatedHistory = [newEntry, ...history].slice(0, 50);
    setHistory(updatedHistory);
    localStorage.setItem('zen_ttt_history', JSON.stringify(updatedHistory));
  }, [history, gameMode]);

  useEffect(() => {
    if (!isGameActive) return;

    if (winner) {
      const newScores = { ...scores, [winner]: scores[winner as 'X' | 'O'] + 1 };
      setScores(newScores);
      localStorage.setItem('zen_ttt_scores', JSON.stringify(newScores));
      setIsGameActive(false);
      playSound('win');
      addHistoryEntry(winner, newScores);
    } else if (isDraw) {
      const newScores = { ...scores, draws: scores.draws + 1 };
      setScores(newScores);
      localStorage.setItem('zen_ttt_scores', JSON.stringify(newScores));
      setIsGameActive(false);
      playSound('draw');
      addHistoryEntry('Draw', newScores);
    }
  }, [winner, isDraw, isGameActive, scores, addHistoryEntry]);

  // AI Turn Handling
  useEffect(() => {
    if (gameMode === 'computer' && !xIsNext && isGameActive && !winner && !isDraw) {
      setIsAiThinking(true);
      const timer = setTimeout(() => {
        const move = findBestMove(board);
        handleSquareClick(move);
        setIsAiThinking(false);
      }, 700);
      return () => clearTimeout(timer);
    }
  }, [xIsNext, gameMode, isGameActive, board, winner, isDraw]);

  const handleSquareClick = useCallback((i: number) => {
    if (board[i] || winner || isDraw || (gameMode === 'computer' && !xIsNext && isAiThinking)) return;

    const newBoard = board.slice();
    newBoard[i] = xIsNext ? 'X' : 'O';
    setBoard(newBoard);
    setXIsNext(!xIsNext);
    playSound('move');
  }, [board, xIsNext, winner, isDraw, isMuted, gameMode, isAiThinking]);

  const resetGame = () => {
    setBoard(INITIAL_BOARD);
    setXIsNext(true);
    setIsGameActive(true);
    setIsAiThinking(false);
    playSound('move');
  };

  const handleStart = (mode: GameMode) => {
    setGameMode(mode);
    setIsStarted(true);
  };

  const clearHistory = () => {
    setHistory([]);
    setScores({ X: 0, O: 0, draws: 0 });
    localStorage.removeItem('zen_ttt_history');
    localStorage.removeItem('zen_ttt_scores');
  };

  const toggleTheme = () => {
    setTheme(prev => prev === Theme.LIGHT ? Theme.DARK : Theme.LIGHT);
  };

  const toggleMute = () => {
    setIsMuted(prev => !prev);
  };

  useEffect(() => {
    const body = document.body;
    if (theme === Theme.DARK) {
      body.classList.add('bg-slate-900', 'text-slate-100');
      body.classList.remove('bg-slate-50', 'text-slate-900');
    } else {
      body.classList.add('bg-slate-50', 'text-slate-900');
      body.classList.remove('bg-slate-900', 'text-slate-100');
    }
  }, [theme]);

  if (!isStarted) {
    return <StartScreen onStart={handleStart} theme={theme} onToggleTheme={toggleTheme} />;
  }

  return (
    <div className={`min-h-screen flex flex-col items-center justify-between p-4 md:p-8 transition-colors duration-300 ${theme === Theme.DARK ? 'dark' : ''}`}>
      <div className="w-full max-w-md flex flex-col gap-6 md:gap-8">
        <Header 
          theme={theme} 
          onToggleTheme={toggleTheme} 
          isMuted={isMuted} 
          onToggleMute={toggleMute}
          onOpenHelp={() => setIsHelpOpen(true)}
          onOpenHistory={() => setIsHistoryOpen(true)}
        />
        
        <div className="flex flex-col gap-2">
           <ScoreBoard scores={scores} theme={theme} />
           <p className={`text-[10px] text-center uppercase tracking-widest font-bold opacity-40 ${theme === Theme.DARK ? 'text-slate-400' : 'text-slate-500'}`}>
              Mode: {gameMode === 'computer' ? 'Versus AI' : 'Versus Friend'}
           </p>
        </div>
        
        <StatusIndicator 
          winner={winner} 
          isDraw={isDraw} 
          xIsNext={xIsNext} 
          theme={theme}
          isAiThinking={isAiThinking}
        />

        <Board 
          squares={board} 
          onClick={handleSquareClick} 
          winningLine={winningLine}
          theme={theme}
          isGameOver={!!winner || isDraw || isAiThinking}
        />

        <Controls onReset={resetGame} theme={theme} onBackToMenu={() => setIsStarted(false)} />
      </div>

      <WinPopup 
        winner={winner} 
        isDraw={isDraw} 
        onReset={resetGame} 
        theme={theme} 
      />

      <HelpModal 
        isOpen={isHelpOpen} 
        onClose={() => setIsHelpOpen(false)} 
        theme={theme} 
      />

      <HistoryModal 
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        history={history}
        theme={theme}
        onClear={clearHistory}
      />
      
      <footer className="mt-8 text-slate-400 text-xs font-medium tracking-widest uppercase text-center">
        Pure Strategy &bull; Zen Experience
      </footer>
    </div>
  );
};

export default App;
